package com.febrian.core.core.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.febrian.core.core.domain.model.Github
import com.febrian.core.databinding.ItemListBinding
import java.util.*

class GithubAdapter : RecyclerView.Adapter<GithubAdapter.ListViewHolder>() {

    private var listData = ArrayList<Github>()
    var onItemClick: ((Github) -> Unit)? = null

    fun setData(newListData: List<Github>?) {
        if (newListData == null) return
        listData.clear()
        listData.addAll(newListData)
        notifyDataSetChanged()
    }

    inner class ListViewHolder(private val binding: ItemListBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(data: Github) {
            Glide.with(itemView.context)
                .load(data.avatar)
                .into(binding.image)
            binding.username.text = data.username
        }

        init {
            binding.root.setOnClickListener {
                onItemClick?.invoke(listData[adapterPosition])
            }
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): GithubAdapter.ListViewHolder {
        val view = ItemListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ListViewHolder(view)
    }

    override fun onBindViewHolder(holder: GithubAdapter.ListViewHolder, position: Int) {
        holder.bind(listData[position])
    }

    override fun getItemCount(): Int = if (listData.size > 10) 10 else listData.size
}